<?php
header("Location:./view/Login.php");
?>